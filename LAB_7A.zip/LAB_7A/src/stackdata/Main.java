package stackdata;

public class Main {
    public static void main(String[] args) {
        // Test LinkedListStack with Integer
        Stack<Integer> linkedListStack = new LinkedListStack<>();
        linkedListStack.push(1);
        linkedListStack.push(2);
        linkedListStack.push(3);
        System.out.println("LinkedListStack (Integer) Peek: " + linkedListStack.peek()); // Output: 3
        System.out.println("LinkedListStack (Integer) Pop: " + linkedListStack.pop());   // Output: 3
        System.out.println("LinkedListStack (Integer) IsEmpty: " + linkedListStack.isEmpty()); // Output: false

        // Test ArrayStack with String
        Stack<String> arrayStack = new ArrayStack<>(5);
        arrayStack.push("A");
        arrayStack.push("B");
        arrayStack.push("C");
        System.out.println("ArrayStack (String) Peek: " + arrayStack.peek()); // Output: C
        System.out.println("ArrayStack (String) Pop: " + arrayStack.pop());   // Output: C
        System.out.println("ArrayStack (String) IsEmpty: " + arrayStack.isEmpty()); // Output: false
    }
}

