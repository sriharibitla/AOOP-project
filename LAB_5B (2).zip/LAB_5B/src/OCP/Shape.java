package OCP;

public interface Shape {
    double calculateArea();
}

