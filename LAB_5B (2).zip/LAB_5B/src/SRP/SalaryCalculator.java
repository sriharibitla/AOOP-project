package SRP;

public class SalaryCalculator {
    // Method to calculate annual salary
    public double calculateAnnualSalary(Employee employee) {
        return employee.getBaseSalary() * 12;
    }

    // Method to calculate monthly salary after deductions
    public double calculateMonthlySalaryAfterDeductions(Employee employee, double deductions) {
        return employee.getBaseSalary() - deductions;
    }

    // Additional methods for salary calculations can be added here
}

