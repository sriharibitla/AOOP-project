package SRP;

public class Main {
    public static void main(String[] args) {
        // Creating an employee
        Employee employee = new Employee("John Doe", 101, "Engineering", 5000);

        // Creating a salary calculator
        SalaryCalculator salaryCalculator = new SalaryCalculator();

        // Calculating annual salary
        double annualSalary = salaryCalculator.calculateAnnualSalary(employee);
        System.out.println("Annual Salary: " + annualSalary);

        // Calculating monthly salary after deductions
        double deductions = 500; // Example deduction
        double monthlySalaryAfterDeductions = salaryCalculator.calculateMonthlySalaryAfterDeductions(employee, deductions);
        System.out.println("Monthly Salary after deductions: " + monthlySalaryAfterDeductions);
    }
}

