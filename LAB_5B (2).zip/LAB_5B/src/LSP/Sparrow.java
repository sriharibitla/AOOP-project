package LSP;

public class Sparrow extends Bird {
	public void fly() {
        System.out.println("Sparrow is flying");
    }
}
