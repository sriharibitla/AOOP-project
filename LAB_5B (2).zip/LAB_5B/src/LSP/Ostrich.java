package LSP;

public class Ostrich extends Bird {
    @Override
    public void fly() {
    	System.out.println("Ostriches cannot fly");
    }
}

