package LSP;

public class Main {
    public static void main(String[] args) {
        Bird genericBird = new Bird();
        Bird Sparrow = new Sparrow();
        Bird ostrich = new Ostrich();

        makeBirdFly(genericBird);  // Bird is flying
        makeBirdFly(Sparrow);   // Flying bird is flying
        makeBirdFly(ostrich);      // Throws UnsupportedOperationException
    }

    public static void makeBirdFly(Bird bird) {
        bird.fly();
    }
}

