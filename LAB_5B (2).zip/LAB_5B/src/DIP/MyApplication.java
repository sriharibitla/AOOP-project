package DIP;

public class MyApplication {
    private final MessageService messageService;

    // Dependency Injection through constructor
    public MyApplication(MessageService messageService) {
        this.messageService = messageService;
    }

    public void processMessage(String message, String recipient) {
        // Some message processing logic could be here
        messageService.sendMessage(message, recipient);
    }
}

