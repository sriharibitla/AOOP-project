package DIP;

public class Main {
    public static void main(String[] args) {
        MessageService emailService = new EmailService();
        MessageService smsService = new SMSService();

        MyApplication appWithEmailService = new MyApplication(emailService);
        MyApplication appWithSMSService = new MyApplication(smsService);

        // Sending messages using different services
        appWithEmailService.processMessage("'Hello' via Email!", "2320030***@klh.edu.in");
        appWithSMSService.processMessage("'Hello' via SMS!", "888****720");
    }
}

