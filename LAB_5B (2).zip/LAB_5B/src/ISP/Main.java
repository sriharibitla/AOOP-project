package ISP;

public class Main {
    public static void main(String[] args) {
        Worker robot = new Robot();
        Human human = new Human();

        makeWorkerWork(robot);   // Robot is working
        makeWorkerWork(human);   // Human is working

        makeEaterEat(human);     // Human is eating
    }

    public static void makeWorkerWork(Worker worker) {
        worker.work();
    }

    public static void makeEaterEat(Eater eater) {
        eater.eat();
    }
}

