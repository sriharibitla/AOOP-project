package logging;

public class InfoHandler extends LogHandler {
    public InfoHandler() {
        super(LogLevel.INFO);
    }

    @Override
    protected boolean canHandle(String message) {
        return message.contains("INFO");
    }

    @Override
    protected void process(String message) {
        System.out.println("INFO: " + message);
    }
}
