package FMDemo;

public interface Shape {
	void draw();
}
