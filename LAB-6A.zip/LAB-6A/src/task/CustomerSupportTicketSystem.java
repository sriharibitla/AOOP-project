package task;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class CustomerSupportTicketSystem {
    public static void main(String[] args) {
        Queue<String> ticketQueue = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add Ticket");
            System.out.println("2. Process Next Ticket");
            System.out.println("3. Display Pending Tickets");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter ticket description: ");
                    ticketQueue.add(scanner.nextLine());
                    break;
                case 2:
                    if (!ticketQueue.isEmpty()) {
                        System.out.println("Processing ticket: " + ticketQueue.poll());
                    } else {
                        System.out.println("No tickets to process.");
                    }
                    break;
                case 3:
                    System.out.println("\nPending Tickets:");
                    for (String ticket : ticketQueue) {
                        System.out.println(ticket);
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }
}
