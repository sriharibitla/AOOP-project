package task;

import java.util.ArrayList;
import java.util.Scanner;

public class TaskManagementSystem {
    public static void main(String[] args) {
        ArrayList<String> tasks = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n1. Add Task");
            System.out.println("2. Update Task");
            System.out.println("3. Remove Task");
            System.out.println("4. Display Tasks");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    System.out.print("Enter task description: ");
                    tasks.add(scanner.nextLine());
                    break;
                case 2:
                    System.out.print("Enter task index to update: ");
                    int indexToUpdate = scanner.nextInt();
                    scanner.nextLine();  
                    if (indexToUpdate >= 0 && indexToUpdate < tasks.size()) {
                        System.out.print("Enter new task description: ");
                        tasks.set(indexToUpdate, scanner.nextLine());
                    } else {
                        System.out.println("Invalid task index.");
                    }
                    break;
                case 3:
                    System.out.print("Enter task index to remove: ");
                    int indexToRemove = scanner.nextInt();
                    if (indexToRemove >= 0 && indexToRemove < tasks.size()) {
                        tasks.remove(indexToRemove);
                    } else {
                        System.out.println("Invalid task index.");
                    }
                    break;
                case 4:
                    System.out.println("\nTasks:");
                    for (int i = 0; i < tasks.size(); i++) {
                        System.out.println(i + ": " + tasks.get(i));
                    }
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
