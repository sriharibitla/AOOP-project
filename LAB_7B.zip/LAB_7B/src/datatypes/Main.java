package datatypes;

public class Main {
    public static void main(String[] args) {
        // Test with Integer
        PriorityQueue<Integer> intQueue = new PriorityQueue<>();
        intQueue.enqueue(5);
        intQueue.enqueue(1);
        intQueue.enqueue(3);
        System.out.println("Integer Queue Peek: " + intQueue.peek()); // Output: 1
        System.out.println("Integer Queue Dequeue: " + intQueue.dequeue()); // Output: 1

        // Test with Double
        PriorityQueue<Double> doubleQueue = new PriorityQueue<>();
        doubleQueue.enqueue(5.5);
        doubleQueue.enqueue(1.1);
        doubleQueue.enqueue(3.3);
        System.out.println("Double Queue Peek: " + doubleQueue.peek()); // Output: 1.1
        System.out.println("Double Queue Dequeue: " + doubleQueue.dequeue()); // Output: 1.1

        // Test with String
        PriorityQueue<String> stringQueue = new PriorityQueue<>();
        stringQueue.enqueue("Banana");
        stringQueue.enqueue("Apple");
        stringQueue.enqueue("Cherry");
        System.out.println("String Queue Peek: " + stringQueue.peek()); // Output: Apple
        System.out.println("String Queue Dequeue: " + stringQueue.dequeue()); // Output: Apple
    }
}

