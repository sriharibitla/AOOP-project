package logging;

//LogCommand class implementing Command interface
class LogCommand implements Command {
 private LogHandler handler;
 private String level;

 public LogCommand(LogHandler handler, String level) {
     this.handler = handler;
     this.level = level;
 }

 @Override
 public void execute(String message) {
     handler.handleRequest(level, message);
 }
}

