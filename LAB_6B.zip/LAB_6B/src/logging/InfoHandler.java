package logging;

class InfoHandler extends LogHandler {
    private static final String LEVEL = "INFO";

    @Override
    protected boolean canHandle(String level) {
        return LEVEL.equalsIgnoreCase(level);
    }

    @Override
    protected void logMessage(String message) {
        System.out.println("INFO: " + message);
    }
}
