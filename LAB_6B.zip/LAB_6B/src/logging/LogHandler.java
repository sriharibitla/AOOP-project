package logging;

abstract class LogHandler {
 protected LogHandler nextHandler;

 public void setNextHandler(LogHandler nextHandler) {
     this.nextHandler = nextHandler;
 }

 public void handleRequest(String level, String message) {
     if (canHandle(level)) {
         logMessage(message);
     } else if (nextHandler != null) {
         nextHandler.handleRequest(level, message);
     }
 }

 protected abstract boolean canHandle(String level);
 protected abstract void logMessage(String message);
}

