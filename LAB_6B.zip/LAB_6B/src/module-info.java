/**
 * 
 */
/**
 * 
 */
module LAB_6B {
}