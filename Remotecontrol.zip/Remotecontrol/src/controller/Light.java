package controller;

public class Light implements Device {
    
    public void turnOn() {
        System.out.println("Light is turned on.");
    }

    
    public void turnOff() {
        System.out.println("Light is turned off.");
    }
}