package controller;

import java.util.HashMap;
import java.util.Map;

public class RemoteControl {
    private Map<String, Device> devices = new HashMap<>();

    public void addDevice(String name, Device device) {
        devices.put(name, device);
    }

    public void turnOnDevice(String name) {
        Device device = devices.get(name);
        if (device != null) {
            device.turnOn();
        } else {
            System.out.println("Device not found.");
        }
    }

    public void turnOffDevice(String name) {
        Device device = devices.get(name);
        if (device != null) {
            device.turnOff();
        } else {
            System.out.println("Device not found.");
        }
    }
}
