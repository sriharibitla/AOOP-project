package controller;

public interface Device {
    void turnOn();
    void turnOff();
}

