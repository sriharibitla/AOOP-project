package controller;

public class Fan implements Device {
    
    public void turnOn() {
        System.out.println("Fan is turned on.");
    }

    
    public void turnOff() {
        System.out.println("Fan is turned off.");
    }
}

