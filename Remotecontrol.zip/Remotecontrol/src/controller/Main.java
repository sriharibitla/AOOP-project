package controller;

public class Main {
    public static void main(String[] args) {
        RemoteControl remote = new RemoteControl();

        Device light = new Light();
        Device fan = new Fan();
        Device tv = new TV();

        remote.addDevice("Living Room Light", light);
        remote.addDevice("Bedroom Fan", fan);
        remote.addDevice("Living Room TV", tv);

        remote.turnOnDevice("Living Room Light");
        remote.turnOnDevice("Bedroom Fan");
        remote.turnOffDevice("Living Room TV");
    }
}
